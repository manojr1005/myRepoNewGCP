"""
Configuration Loader Module
Reads Dialogflow CX configuration from BOT-TO-TEST-CONFIGURATION-INFO.txt

PROPRIETARY NOTICE:
This code is proprietary and belongs to Miratech.
Copyright (c) Miratech. All rights reserved.
Contact: Nikhil.Kodilkar@gmail.com
"""

import os
from pathlib import Path
from typing import Dict, Optional


def load_config(config_file: Optional[str] = None) -> Dict[str, any]:
    """
    Load configuration from BOT-TO-TEST-CONFIGURATION-INFO.txt
    
    Args:
        config_file: Optional path to config file. If None, looks for 
                    BOT-TO-TEST-CONFIGURATION-INFO.txt in the audio-service directory
    
    Returns:
        dict with configuration parameters
    
    Raises:
        FileNotFoundError: If config file doesn't exist
        ValueError: If required parameters are missing or invalid
    """
    if config_file is None:
        # Look for config file in audio-service directory
        script_dir = Path(__file__).parent.parent
        config_file = script_dir / 'BOT-TO-TEST-CONFIGURATION-INFO.txt'
    else:
        config_file = Path(config_file)
    
    if not config_file.exists():
        raise FileNotFoundError(
            f"Configuration file not found: {config_file}\n"
            f"Please create BOT-TO-TEST-CONFIGURATION-INFO.txt with your Dialogflow CX settings."
        )
    
    print(f"[DEBUG] Loading configuration from: {config_file}")
    
    # Read and parse config file
    config = {}
    with open(config_file, 'r', encoding='utf-8') as f:
        for line_num, line in enumerate(f, 1):
            # Skip comments and empty lines
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            
            # Parse Python-style assignments
            if '=' in line:
                try:
                    # Split on = and strip whitespace
                    key, value = line.split('=', 1)
                    key = key.strip()
                    value = value.strip()
                    
                    # Remove quotes if present
                    if value.startswith('"') and value.endswith('"'):
                        value = value[1:-1]
                    elif value.startswith("'") and value.endswith("'"):
                        value = value[1:-1]
                    
                    # Convert boolean strings
                    if value.lower() == 'true':
                        value = True
                    elif value.lower() == 'false':
                        value = False
                    
                    config[key] = value
                except Exception as e:
                    print(f"[WARNING] Skipping invalid line {line_num}: {line}")
                    print(f"[WARNING] Error: {e}")
    
    print(f"[DEBUG] Loaded {len(config)} configuration parameters")
    
    # Handle platform selection first (needed for validation)
    if 'PLATFORM' not in config:
        config['PLATFORM'] = 'dialogflow'  # Default to Dialogflow for backward compatibility
    else:
        platform = config['PLATFORM'].lower()
        if platform not in ['dialogflow', 'amazon_lex', 'lex']:
            print(f"[WARNING] Invalid PLATFORM value: {config['PLATFORM']}. Using 'dialogflow' as default.")
            config['PLATFORM'] = 'dialogflow'
        else:
            # Normalize 'lex' to 'amazon_lex'
            if platform == 'lex':
                config['PLATFORM'] = 'amazon_lex'
            else:
                config['PLATFORM'] = platform
    
    # Validate required parameters based on platform
    platform = config['PLATFORM']
    
    if platform == 'dialogflow':
        # Validate Dialogflow-specific required parameters
        required_params = ['PROJECT_ID', 'LOCATION', 'AGENT_ID', 'CREDS_PATH']
        missing_params = [p for p in required_params if p not in config or not config[p]]
        
        if missing_params:
            raise ValueError(
                f"Missing required Dialogflow configuration parameters: {', '.join(missing_params)}\n"
                f"Please check your BOT-TO-TEST-CONFIGURATION-INFO.txt file."
            )
        
        # Validate that creds_path file exists (if not absolute, make relative to config file)
        creds_path = Path(config['CREDS_PATH'])
        if not creds_path.is_absolute():
            # Make relative to config file directory
            creds_path = config_file.parent / creds_path
        
        if not creds_path.exists():
            print(f"[WARNING] Service account key file not found: {creds_path}")
            print(f"[WARNING] This will cause an error when connecting to Dialogflow")
        else:
            print(f"[DEBUG] Service account key file found: {creds_path}")
            # Update config with absolute path
            config['CREDS_PATH'] = str(creds_path)
    
    # Handle optional parameters with defaults
    if 'FLOW_ID' not in config:
        config['FLOW_ID'] = None
    elif config['FLOW_ID'] == '':
        config['FLOW_ID'] = None
    
    if 'PAGE_ID' not in config:
        config['PAGE_ID'] = None
    elif config['PAGE_ID'] == '':
        config['PAGE_ID'] = None
    
    if 'START_WITH_GREETING' not in config:
        config['START_WITH_GREETING'] = False
    
    # Validate Amazon Lex configuration if Lex is selected
    if config['PLATFORM'] == 'amazon_lex':
        required_lex_params = ['LEX_BOT_ID', 'LEX_BOT_ALIAS_ID', 'LEX_LOCALE_ID', 'AWS_REGION']
        missing_params = [p for p in required_lex_params if p not in config or not config[p]]
        if missing_params:
            raise ValueError(
                f"Amazon Lex is selected but missing required parameters: {', '.join(missing_params)}\n"
                "Please set these in BOT-TO-TEST-CONFIGURATION-INFO.txt"
            )
        print(f"[DEBUG] Amazon Lex configured: Bot={config['LEX_BOT_ID']}, Region={config['AWS_REGION']}")
    
    # Handle TTS service configuration
    if 'TTS_SERVICE' not in config:
        config['TTS_SERVICE'] = 'google'
    else:
        tts_service = config['TTS_SERVICE'].lower()
        if tts_service not in ['edge', 'google', 'azure']:
            print(f"[WARNING] Invalid TTS_SERVICE value: {config['TTS_SERVICE']}. Using 'google' as default.")
            config['TTS_SERVICE'] = 'google'
        else:
            config['TTS_SERVICE'] = tts_service
    
    # Validate Azure TTS configuration if Azure is selected
    if config['TTS_SERVICE'] == 'azure':
        if 'AZURE_SPEECH_KEY' not in config or not config['AZURE_SPEECH_KEY']:
            raise ValueError(
                "Azure TTS is selected but AZURE_SPEECH_KEY is not set.\n"
                "Please set AZURE_SPEECH_KEY in BOT-TO-TEST-CONFIGURATION-INFO.txt"
            )
        if 'AZURE_SPEECH_REGION' not in config or not config['AZURE_SPEECH_REGION']:
            raise ValueError(
                "Azure TTS is selected but AZURE_SPEECH_REGION is not set.\n"
                "Please set AZURE_SPEECH_REGION in BOT-TO-TEST-CONFIGURATION-INFO.txt"
            )
        print(f"[DEBUG] Azure TTS configured: Region={config['AZURE_SPEECH_REGION']}")
    
    print(f"[DEBUG] Configuration loaded successfully:")
    print(f"  PLATFORM: {config.get('PLATFORM', 'dialogflow')}")
    if config.get('PLATFORM', 'dialogflow') == 'dialogflow':
        print(f"  PROJECT_ID: {config['PROJECT_ID']}")
        print(f"  LOCATION: {config['LOCATION']}")
        print(f"  AGENT_ID: {config['AGENT_ID']}")
        print(f"  CREDS_PATH: {config['CREDS_PATH']}")
        print(f"  FLOW_ID: {config.get('FLOW_ID', 'Not set')}")
        print(f"  PAGE_ID: {config.get('PAGE_ID', 'Not set')}")
    else:
        print(f"  LEX_BOT_ID: {config.get('LEX_BOT_ID', 'Not set')}")
        print(f"  LEX_BOT_ALIAS_ID: {config.get('LEX_BOT_ALIAS_ID', 'Not set')}")
        print(f"  LEX_LOCALE_ID: {config.get('LEX_LOCALE_ID', 'Not set')}")
        print(f"  AWS_REGION: {config.get('AWS_REGION', 'Not set')}")
    print(f"  START_WITH_GREETING: {config.get('START_WITH_GREETING', False)}")
    print(f"  TTS_SERVICE: {config.get('TTS_SERVICE', 'google')}")
    
    return config

