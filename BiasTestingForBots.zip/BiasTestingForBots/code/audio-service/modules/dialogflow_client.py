"""
Dialogflow CX Client Module
Handles connection and interaction with Dialogflow CX

PROPRIETARY NOTICE:
This code is proprietary and belongs to Miratech.
Copyright (c) Miratech. All rights reserved.
Contact: Nikhil.Kodilkar@gmail.com
"""

import uuid
from pathlib import Path
from google.cloud.dialogflowcx_v3.services.sessions import SessionsClient
from google.cloud.dialogflowcx_v3.types import audio_config, session


class DialogflowClient:
    """Client for interacting with Dialogflow CX"""
    
    def __init__(self, project_id, location, agent_id):
        """
        Initialize Dialogflow CX client
        
        Args:
            project_id: Google Cloud project ID
            location: Dialogflow CX location (e.g., 'us-central1')
            agent_id: Dialogflow CX agent ID
            creds_path: Path to service account JSON key file
        """
        self.project_id = project_id
        self.location = location
        self.agent_id = agent_id
        #self.creds_path = Path(creds_path)
        
        #if not self.creds_path.exists():
        #    raise FileNotFoundError(f"Service account key file not found: {creds_path}")
        
        # Set credentials environment variable for Google Cloud client
        import os
        #os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = str(self.creds_path)
        
        # Initialize client
        client_options = None
        if location != "global":
            api_endpoint = f"{location}-dialogflow.googleapis.com:443"
            client_options = {"api_endpoint": api_endpoint}
            print(f"[DEBUG] Using regional endpoint: {api_endpoint}")
        else:
            print(f"[DEBUG] Using default endpoint for global location")
        
        print(f"[DEBUG] Client options: {client_options}")
        self.sessions_client = SessionsClient(client_options=client_options)
        print(f"[DEBUG] SessionsClient initialized successfully")
        
        # Construct agent path
        self.agent_path = f"projects/{project_id}/locations/{location}/agents/{agent_id}"
    
    def create_session(self):
        """Create a new session ID"""
        return str(uuid.uuid4())
    
    def get_session_path(self, session_id):
        """Get full session path"""
        return self.sessions_client.session_path(
            project=self.project_id,
            location=self.location,
            agent=self.agent_id,
            session=session_id
        )
    
    def test_audio_file(self, audio_file_path, session_id=None, start_with_greeting=False, 
                       flow_id=None, page_id=None):
        """
        Test an audio file with Dialogflow CX using streaming API
        
        Args:
            audio_file_path: Path to audio file (WAV, 16kHz, mono, 16-bit PCM)
            session_id: Optional session ID (creates new if not provided)
            start_with_greeting: If True, send greeting first, then audio
            flow_id: Optional flow ID to start from
            page_id: Optional page ID to start from
        
        Returns:
            dict with response data including transcript, intents, parameters
        """
        audio_file_path = Path(audio_file_path)
        
        if not audio_file_path.exists():
            print(f"[ERROR] Audio file does not exist: {audio_file_path}")
            return {
                'success': False,
                'error': f'Audio file not found: {audio_file_path}'
            }
        
        file_size = audio_file_path.stat().st_size
        print(f"[DEBUG] Testing audio file: {audio_file_path.name} ({file_size} bytes)")
        
        if session_id is None:
            session_id = self.create_session()
        
        print(f"[DEBUG] Session ID: {session_id}")
        session_path = self.get_session_path(session_id)
        print(f"[DEBUG] Session path: {session_path}")
        
        if flow_id and page_id:
            print(f"[DEBUG] Starting from page: {flow_id}/{page_id}")
        if start_with_greeting:
            print(f"[DEBUG] Will start with greeting")
        
        def request_generator():
            try:
                print(f"[DEBUG] Request generator started")
                audio_encoding = audio_config.AudioEncoding.AUDIO_ENCODING_LINEAR_16
                print(f"[DEBUG] Audio encoding: {audio_encoding}")
                
                config = audio_config.InputAudioConfig(
                    audio_encoding=audio_encoding,
                    sample_rate_hertz=16000,
                    single_utterance=True,
                )
                print(f"[DEBUG] Audio config created: sample_rate=16000, single_utterance=True")
                
                # Set up query parameters if flow/page specified
                query_params = None
                if flow_id and page_id:
                    page_path = f"{self.agent_path}/flows/{flow_id}/pages/{page_id}"
                    query_params = session.QueryParameters(current_page=page_path)
                    print(f"[DEBUG] Query params set: current_page={page_path}")
                else:
                    print(f"[DEBUG] No query params (flow_id={flow_id}, page_id={page_id})")
                
                # First request: send configuration only (no audio)
                print(f"[DEBUG] Creating first request (config only)...")
                audio_input = session.AudioInput(config=config)
                query_input = session.QueryInput(
                    audio=audio_input,
                    language_code='en'
                )
                
                request = session.StreamingDetectIntentRequest(
                    session=session_path,
                    query_input=query_input,
                    enable_partial_response=True,
                )
                
                if query_params:
                    request.query_params = query_params
                
                print(f"[DEBUG] Yielding first request (config)...")
                yield request
                print(f"[DEBUG] First request yielded successfully")
                
                # Stream audio file in chunks
                print(f"[DEBUG] Opening audio file for streaming: {audio_file_path}")
                chunk_count = 0
                total_bytes = 0
                
                if not audio_file_path.exists():
                    print(f"[ERROR] Audio file does not exist in generator: {audio_file_path}")
                    raise FileNotFoundError(f"Audio file not found: {audio_file_path}")
                
                with open(audio_file_path, "rb") as audio_file:
                    print(f"[DEBUG] Audio file opened, starting to read chunks...")
                    while True:
                        chunk = audio_file.read(4096)  # 4KB chunks
                        if not chunk:
                            print(f"[DEBUG] No more chunks to read (EOF)")
                            break
                        chunk_count += 1
                        total_bytes += len(chunk)
                        print(f"[DEBUG] Read chunk {chunk_count}: {len(chunk)} bytes (total: {total_bytes} bytes)")
                        
                        audio_input = session.AudioInput(audio=chunk)
                        query_input = session.QueryInput(
                            audio=audio_input,
                            language_code='en'
                        )
                        request = session.StreamingDetectIntentRequest(
                            session=session_path,
                            query_input=query_input,
                            enable_partial_response=True,
                        )
                        if query_params:
                            request.query_params = query_params
                        
                        print(f"[DEBUG] Yielding audio chunk request {chunk_count}...")
                        yield request
                        print(f"[DEBUG] Audio chunk request {chunk_count} yielded successfully")
                
                print(f"[DEBUG] Request generator completed: {chunk_count} chunks ({total_bytes} bytes)")
            except Exception as gen_error:
                print(f"[ERROR] Exception in request generator: {type(gen_error).__name__}: {gen_error}")
                import traceback
                print(f"[ERROR] Generator traceback:")
                traceback.print_exc()
                raise
        
        # Get responses
        print(f"[DEBUG] Calling streaming_detect_intent API...")
        print(f"[DEBUG] Session client type: {type(self.sessions_client)}")
        print(f"[DEBUG] Agent path: {self.agent_path}")
        print(f"[DEBUG] Session path: {session_path}")
        print(f"[DEBUG] Location: {self.location}")
        
        try:
            print(f"[DEBUG] Creating request generator...")
            gen = request_generator()
            print(f"[DEBUG] Request generator created: {type(gen)}")
            
            print(f"[DEBUG] Calling streaming_detect_intent with generator...")
            responses = self.sessions_client.streaming_detect_intent(requests=gen)
            print(f"[DEBUG] streaming_detect_intent returned: {type(responses)}")
        except Exception as api_error:
            print(f"[ERROR] Dialogflow API call failed: {type(api_error).__name__}: {api_error}")
            print(f"[ERROR] Error args: {api_error.args}")
            import traceback
            print(f"[ERROR] Full traceback:")
            traceback.print_exc()
            return {
                'success': False,
                'error': f'API call failed: {str(api_error)}'
            }
        
        # Process responses
        print(f"[DEBUG] Processing responses...")
        print(f"[DEBUG] Response iterator type: {type(responses)}")
        final_response = None
        response_count = 0
        
        try:
            print(f"[DEBUG] Starting to iterate over responses...")
            for response in responses:
                response_count += 1
                print(f"[DEBUG] Received response #{response_count}: {type(response)}")
                print(f"[DEBUG] Response attributes: {dir(response)}")
                
                if hasattr(response, 'detect_intent_response'):
                    print(f"[DEBUG] Response has detect_intent_response attribute")
                    if response.detect_intent_response:
                        final_response = response.detect_intent_response
                        print(f"[DEBUG] Found final response in response #{response_count}")
                    else:
                        print(f"[DEBUG] detect_intent_response is None or empty")
                else:
                    print(f"[DEBUG] Response does not have detect_intent_response attribute")
                
                if hasattr(response, 'recognition_result'):
                    print(f"[DEBUG] Response has recognition_result: {response.recognition_result}")
                if hasattr(response, 'message'):
                    print(f"[DEBUG] Response has message: {response.message}")
                    
            print(f"[DEBUG] Finished iterating. Processed {response_count} responses")
        except Exception as iter_error:
            print(f"[ERROR] Exception while iterating responses: {type(iter_error).__name__}: {iter_error}")
            import traceback
            print(f"[ERROR] Iteration traceback:")
            traceback.print_exc()
            return {
                'success': False,
                'error': f'Error processing responses: {str(iter_error)}'
            }
        
        if not final_response:
            print(f"[ERROR] No final response received from Dialogflow")
            return {
                'success': False,
                'error': 'No response from Dialogflow'
            }
        
        # Extract data from response
        query_result = final_response.query_result
        print(f"[DEBUG] Query result received")
        print(f"[DEBUG] Transcript: {query_result.transcript if query_result.transcript else 'N/A'}")
        print(f"[DEBUG] Intent: {query_result.intent.display_name if query_result.intent else 'N/A'}")
        print(f"[DEBUG] Confidence: {query_result.intent_detection_confidence}")
        
        # Extract response text
        response_texts = []
        for msg in query_result.response_messages:
            if msg.text and msg.text.text:
                response_texts.extend(msg.text.text)
        
        response_text = "\n".join(response_texts) if response_texts else 'NO_RESPONSE'
        
        # Extract parameters
        params = query_result.parameters or {}
        
        return {
            'success': True,
            'session_id': session_id,
            'transcript': query_result.transcript or '',
            'response_text': response_text,
            'intent': {
                'name': query_result.intent.display_name if query_result.intent else '',
                'confidence': query_result.intent_detection_confidence
            },
            'parameters': {
                'headIntent': params.get('headIntent', ''),
                'subIntent': params.get('subIntent', ''),
                'caller_type': params.get('caller_type', ''),
                'payments_query_type': params.get('payments_query_type', ''),
                'benefits_type': params.get('benefits_type', '')
            },
            'confidence': query_result.intent_detection_confidence
        }

