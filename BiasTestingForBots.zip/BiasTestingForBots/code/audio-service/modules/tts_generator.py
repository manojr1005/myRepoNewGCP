# =============================================================
# TTS + STT (Whisper) Audio Generation Module
# Generates 12 audio variations per utterance (2 genders × 6 accents)
# =============================================================

import os
import csv
import asyncio
from pathlib import Path
import pandas as pd
import edge_tts

# -----------------------------
# Optional providers
# -----------------------------
try:
    from google.cloud import texttospeech
    GOOGLE_TTS_AVAILABLE = True
except Exception:
    GOOGLE_TTS_AVAILABLE = False

try:
    import azure.cognitiveservices.speech as speechsdk
    AZURE_TTS_AVAILABLE = True
except Exception:
    AZURE_TTS_AVAILABLE = False

# -----------------------------
# STT (Whisper)
# -----------------------------
try:
    import whisper
    WHISPER_AVAILABLE = True
except Exception:
    WHISPER_AVAILABLE = False

# -----------------------------
# Configuration
# -----------------------------
ACCENTS = [
    'indian_english',
    'french_english',
    'chinese_english',
    'spanish_english',
    'australian_english',
    'regular_english'
]

GENDERS = ['male', 'female']
TOTAL_VARIANTS = len(ACCENTS) * len(GENDERS)
PRINT_BATCH = 100

# =============================================================
# Voice discovery
# =============================================================

async def discover_voices_edge():
    voices = await edge_tts.list_voices()
    english_voices = [v for v in voices if v['Locale'].startswith('en')]
    used = set()

    voice_map = {a: {'male': None, 'female': None} for a in ACCENTS}

    for accent in ACCENTS:
        for gender in ['Male', 'Female']:
            matches = [
                v for v in english_voices
                if v['Gender'] == gender and v['ShortName'] not in used
            ]
            if matches:
                voice_map[accent][gender.lower()] = matches[0]['ShortName']
                used.add(matches[0]['ShortName'])

    return voice_map


def discover_voices_google(creds_path=None):
    if not GOOGLE_TTS_AVAILABLE:
        raise ImportError('google-cloud-texttospeech not installed')
    client = (
        texttospeech.TextToSpeechClient.from_service_account_file(creds_path)
        if creds_path else texttospeech.TextToSpeechClient()
    )
    voices = client.list_voices().voices
    voice_map = {a: {'male': None, 'female': None} for a in ACCENTS}
    for v in voices:
        if v.ssml_gender == texttospeech.SsmlVoiceGender.MALE:
            for a in ACCENTS:
                if voice_map[a]['male'] is None:
                    voice_map[a]['male'] = v.name
        if v.ssml_gender == texttospeech.SsmlVoiceGender.FEMALE:
            for a in ACCENTS:
                if voice_map[a]['female'] is None:
                    voice_map[a]['female'] = v.name
    return voice_map


def discover_voices_azure(azure_key=None, azure_region=None):
    if not AZURE_TTS_AVAILABLE:
        raise ImportError('azure-cognitiveservices-speech not installed')
    import requests
    url = f"https://{azure_region}.tts.speech.microsoft.com/cognitiveservices/voices/list"
    r = requests.get(url, headers={"Ocp-Apim-Subscription-Key": azure_key})
    r.raise_for_status()
    voices = r.json()
    voice_map = {a: {'male': None, 'female': None} for a in ACCENTS}
    for v in voices:
        g = v.get('Gender', '').lower()
        for a in ACCENTS:
            if g in voice_map[a] and voice_map[a][g] is None:
                voice_map[a][g] = v['ShortName']
    return voice_map


async def discover_voices(tts_service='edge', creds_path=None, azure_key=None, azure_region=None):
    tts_service = tts_service.lower()
    if tts_service == 'google':
        return discover_voices_google(creds_path)
    if tts_service == 'azure':
        return discover_voices_azure(azure_key, azure_region)
    return await discover_voices_edge()

# =============================================================
# Audio + STT
# =============================================================

async def generate_audio_edge(text, voice, path):
    await edge_tts.Communicate(text, voice).save(str(path))
    return path.exists()


def load_stt_model(name='tiny'):
    if not WHISPER_AVAILABLE:
        raise ImportError('openai-whisper not installed')
    return whisper.load_model(name)


def transcribe(path, model):
    r = model.transcribe(str(path), fp16=False)
    return (r.get('text') or '').strip()

# =============================================================
# CSV helpers
# =============================================================

def init_csv(path, cols):
    if path.exists():
        return
    with path.open('w', newline='', encoding='utf-8') as f:
        csv.writer(f).writerow(
            ['utterance_id', 'Utterance', 'accent', 'gender', 'voice', 'stt_text', 'status', *cols]
        )


def append_csv(path, rows):
    with path.open('a', newline='', encoding='utf-8') as f:
        csv.writer(f).writerows(rows)


def csv_to_excel(csv_path, xls_path):
    pd.read_csv(csv_path).to_excel(xls_path, index=False)

# =============================================================
# Core pipeline
# =============================================================

async def process_single_variation(
    uid, text, meta, accent, gender, voice, tmp, model,
    tts_service, creds_path, azure_key, azure_region
):
    mp3 = tmp / f"{uid}_{accent}_{gender}.mp3"
    ok = await generate_audio_edge(text, voice, mp3)
    if not ok:
        return {**meta, 'utterance_id': uid, 'Utterance': text,
                'accent': accent, 'gender': gender, 'voice': voice,
                'stt_text': '', 'status': 'generation_failed'}
    try:
        stt = transcribe(mp3, model)
    finally:
        mp3.unlink(missing_ok=True)

    return {**meta, 'utterance_id': uid, 'Utterance': text,
            'accent': accent, 'gender': gender, 'voice': voice,
            'stt_text': stt, 'status': 'success' if stt else 'stt_failed'}


async def generate_utterance_variations(
    uid, text, meta, voice_map, out, csv_path, model,
    batch_size, tts_service, creds_path, azure_key, azure_region
):
    tasks = []
    for a in ACCENTS:
        for g in GENDERS:
            v = voice_map.get(a, {}).get(g)
            if not v:
                append_csv(csv_path, [[uid, text, a, g, '', '', 'voice_not_found', *meta.values()]])
                continue
            tasks.append(process_single_variation(
                uid, text, meta, a, g, v, out, model,
                tts_service, creds_path, azure_key, azure_region
            ))
    results = await asyncio.gather(*tasks)
    append_csv(csv_path, [[
        r['utterance_id'], r['Utterance'], r['accent'], r['gender'],
        r['voice'], r['stt_text'], r['status'], *meta.values()
    ] for r in results])


async def process_excel_file(
    excel_path, output_dir, output_file, limit=None,
    tts_service='edge', creds_path=None,
    azure_key=None, azure_region=None,
    stt_model_name='tiny', batch_size=4
):
    df = pd.read_excel(excel_path)
    valid = df[df['Utterance'].notna() & df['Utterance'].astype(str).str.strip().ne('')]
    if limit:
        valid = valid.head(limit)

    total = len(valid)
    print(f"Total utterances to be processed: {total}")

    voices = await discover_voices(tts_service, creds_path, azure_key, azure_region)
    model = load_stt_model(stt_model_name)

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    csv_path = out / f"{output_file}.csv"
    xls_path = out / f"{output_file}.xlsx"

    cols = [c for c in df.columns if c != 'Utterance']
    init_csv(csv_path, cols)

    batch_start = 1

    for i, (_, row) in enumerate(valid.iterrows(), start=1):
        if i == batch_start:
            end = min(batch_start + PRINT_BATCH - 1, total)
            print(f"Processing utterances {batch_start} to {end} ({TOTAL_VARIANTS}/{TOTAL_VARIANTS} variations per utterance)")

        await generate_utterance_variations(
            i, row['Utterance'], {c: row[c] for c in cols}, voices, out,
            csv_path, model, batch_size,
            tts_service, creds_path, azure_key, azure_region
        )

        if i == end:
            print(f"Completed processing utterances {batch_start} to {end} ({TOTAL_VARIANTS}/{TOTAL_VARIANTS} variations per utterance)")
            batch_start = i + 1

    csv_to_excel(csv_path, xls_path)

    successful = pd.read_csv(csv_path)['status'].eq('success').sum()

    print("\n======================================================================")
    print("PIPELINE COMPLETED SUCCESSFULLY")
    print("======================================================================")
    print(f"Utterances processed: {total}")
    print(f"Successful outputs: {successful} / {total * TOTAL_VARIANTS}")
    print(f"CSV output: {csv_path}")
    print(f"Excel output: {xls_path}")
    print(f"JSON summary: {Path(output_dir) / f'{output_file}.json'}")
    print("======================================================================\n")

    return None


def generate_audio_files(
    excel_path,
    output_dir,
    output_file,
    limit=None,
    tts_service='edge',
    creds_path=None,
    azure_key=None,
    azure_region=None,
    stt_model_name='tiny',
    batch_size=4,
):
    return asyncio.run(
        process_excel_file(
            Path(excel_path),
            Path(output_dir),
            output_file,
            limit,
            tts_service,
            creds_path,
            azure_key,
            azure_region,
            stt_model_name,
            batch_size,
        )
    )