"""
Amazon Lex Client Module
Handles connection and interaction with Amazon Lex bots

PROPRIETARY NOTICE:
This code is proprietary and belongs to Miratech.
Copyright (c) Miratech. All rights reserved.
Contact: Nikhil.Kodilkar@gmail.com
"""

import uuid
from pathlib import Path
import boto3
from botocore.exceptions import ClientError, BotoCoreError


class AmazonLexClient:
    """Client for interacting with Amazon Lex bots"""
    
    def __init__(self, bot_id, bot_alias_id, locale_id, aws_region, 
                 aws_access_key_id=None, aws_secret_access_key=None):
        """
        Initialize Amazon Lex client
        
        Args:
            bot_id: Amazon Lex bot ID
            bot_alias_id: Amazon Lex bot alias ID
            locale_id: Locale ID (e.g., 'en_US', 'es_US')
            aws_region: AWS region (e.g., 'us-east-1')
            aws_access_key_id: Optional AWS access key ID
            aws_secret_access_key: Optional AWS secret access key
        """
        self.bot_id = bot_id
        self.bot_alias_id = bot_alias_id
        self.locale_id = locale_id
        self.aws_region = aws_region
        
        # Initialize boto3 Lex Runtime client
        try:
            if aws_access_key_id and aws_secret_access_key:
                self.lex_client = boto3.client(
                    'lex-runtime',
                    region_name=aws_region,
                    aws_access_key_id=aws_access_key_id,
                    aws_secret_access_key=aws_secret_access_key
                )
                print(f"[DEBUG] Using explicit AWS credentials")
            else:
                # Use default credentials (environment variables, IAM role, etc.)
                self.lex_client = boto3.client(
                    'lex-runtime',
                    region_name=aws_region
                )
                print(f"[DEBUG] Using default AWS credentials")
            
            print(f"[DEBUG] Lex Runtime client initialized: region={aws_region}")
            print(f"[DEBUG] Bot ID: {bot_id}, Alias: {bot_alias_id}, Locale: {locale_id}")
        except Exception as e:
            print(f"[ERROR] Failed to initialize Lex client: {e}")
            raise
    
    def create_session(self):
        """Create a new session ID"""
        return str(uuid.uuid4())
    
    def test_audio_file(self, audio_file_path, session_id=None, start_with_greeting=False):
        """
        Test an audio file with Amazon Lex using post_content API
        
        Args:
            audio_file_path: Path to audio file (WAV, 8kHz or 16kHz, mono, PCM)
            session_id: Optional session ID (creates new if not provided)
            start_with_greeting: If True, send greeting first, then audio (not supported in Lex)
        
        Returns:
            dict with response data including transcript, intents, slots
        """
        audio_file_path = Path(audio_file_path)
        
        if not audio_file_path.exists():
            print(f"[ERROR] Audio file does not exist: {audio_file_path}")
            return {
                'success': False,
                'error': f'Audio file not found: {audio_file_path}'
            }
        
        file_size = audio_file_path.stat().st_size
        print(f"[DEBUG] Testing audio file: {audio_file_path.name} ({file_size} bytes)")
        
        if session_id is None:
            session_id = self.create_session()
        
        print(f"[DEBUG] Session ID: {session_id}")
        
        if start_with_greeting:
            print(f"[WARNING] start_with_greeting is not supported for Amazon Lex, ignoring")
        
        try:
            # Read audio file
            with open(audio_file_path, 'rb') as audio_file:
                audio_content = audio_file.read()
            
            print(f"[DEBUG] Calling Lex post_content API...")
            
            # Call Lex post_content API
            response = self.lex_client.post_content(
                botName=self.bot_id,
                botAlias=self.bot_alias_id,
                userId=session_id,
                contentType='audio/l16; rate=16000; channels=1',
                accept='text/plain; charset=utf-8',
                inputStream=audio_content
            )
            
            print(f"[DEBUG] Lex response received")
            
            # Extract response data
            transcript = response.get('inputTranscript', '')
            intent_name = response.get('intentName', '')
            slots = response.get('slots', {})
            
            # Get response message
            response_text = ''
            if 'message' in response:
                message = response['message']
                if isinstance(message, bytes):
                    response_text = message.decode('utf-8')
                else:
                    response_text = str(message)
            
            # Get dialog state
            dialog_state = response.get('dialogState', '')
            session_attributes = response.get('sessionAttributes', {})
            
            print(f"[DEBUG] Transcript: {transcript}")
            print(f"[DEBUG] Intent: {intent_name}")
            print(f"[DEBUG] Dialog State: {dialog_state}")
            print(f"[DEBUG] Slots: {slots}")
            
            # Convert slots to parameters format (similar to Dialogflow)
            parameters = {}
            if slots:
                for slot_name, slot_value in slots.items():
                    if slot_value:
                        # Extract slot value (can be dict or string)
                        if isinstance(slot_value, dict):
                            parameters[slot_name] = slot_value.get('value', {}).get('originalValue', '')
                        else:
                            parameters[slot_name] = str(slot_value)
            
            return {
                'success': True,
                'session_id': session_id,
                'transcript': transcript,
                'response_text': response_text,
                'intent': {
                    'name': intent_name,
                    'confidence': 1.0  # Lex doesn't provide confidence in post_content
                },
                'parameters': {
                    'headIntent': intent_name,  # Lex doesn't have head/sub intent concept
                    'subIntent': '',
                    'caller_type': parameters.get('caller_type', ''),
                    'payments_query_type': parameters.get('payments_query_type', ''),
                    'benefits_type': parameters.get('benefits_type', ''),
                    **parameters  # Include all slots as parameters
                },
                'confidence': 1.0,
                'dialog_state': dialog_state,
                'session_attributes': session_attributes
            }
            
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_message = e.response.get('Error', {}).get('Message', str(e))
            print(f"[ERROR] Lex API error: {error_code} - {error_message}")
            return {
                'success': False,
                'error': f'Lex API error: {error_code} - {error_message}'
            }
        except BotoCoreError as e:
            print(f"[ERROR] Boto3 error: {e}")
            return {
                'success': False,
                'error': f'Boto3 error: {str(e)}'
            }
        except Exception as e:
            print(f"[ERROR] Unexpected error: {type(e).__name__}: {e}")
            import traceback
            traceback.print_exc()
            return {
                'success': False,
                'error': f'Unexpected error: {str(e)}'
            }

