# Dialogflow CX Audio Testing Pipeline

A modular Python system for testing Dialogflow CX agents with audio input across multiple accents and voice variations.

## Overview

This pipeline:
1. **Generates TTS audio files** - Creates 12 variations per utterance (2 genders × 6 accents)
2. **Tests with Dialogflow CX** - Sends audio files to Dialogflow and records responses
3. **Generates reports** - Creates Excel reports with pass percentages and detailed results

## Architecture

The system is modular with separate Python scripts for each function:

- **`main.py`** - Main orchestrator script that coordinates all modules
- **`modules/tts_generator.py`** - Generates TTS audio files using Edge TTS or Google Cloud TTS
- **`modules/dialogflow_client.py`** - Handles Dialogflow CX connection and audio streaming
- **`modules/audio_tester.py`** - Tests audio files with Dialogflow
- **`modules/report_generator.py`** - Generates Excel reports with results

## Installation

1. Install Python dependencies:
```powershell
cd audio-service
pip install -r requirements.txt
```

2. Configure Dialogflow CX settings:
   - Open `BOT-TO-TEST-CONFIGURATION-INFO.txt`
   - Update the following required parameters:
     - `PROJECT_ID` - Your Google Cloud Project ID
     - `LOCATION` - Dialogflow CX location (e.g., us-central1)
     - `AGENT_ID` - Your Dialogflow CX Agent ID
     - `CREDS_PATH` - Path to your service account JSON key file
   - Optionally configure:
     - `FLOW_ID` - Flow ID to start from (leave empty if not needed)
     - `PAGE_ID` - Page ID to start from (leave empty if not needed)
     - `START_WITH_GREETING` - Set to True/False
     - `TTS_SERVICE` - TTS service to use: "google" (default, free tier available) or "edge" (free, no API key required)

3. Set up Google Cloud credentials (for Dialogflow CX and optionally for Google TTS):
   - Create a service account in Google Cloud Console
   - Download the JSON key file
   - Update `CREDS_PATH` in the configuration file to point to this file
   - **Google TTS is the default** (`TTS_SERVICE = "google"`):
     - Enable the Cloud Text-to-Speech API in your Google Cloud project
     - Set the `GOOGLE_APPLICATION_CREDENTIALS` environment variable to point to your service account key file, OR
     - Ensure your service account has Text-to-Speech API permissions
     - **Note**: Google TTS has a free tier: 4 million characters/month (standard voices) or 1 million characters/month (WaveNet voices). Beyond that, pricing is $4 per 1M characters (standard) or $16 per 1M characters (WaveNet).
   - To use Edge TTS instead, set `TTS_SERVICE = "edge"` in the configuration file

## Usage

### Basic Usage

```powershell
python main.py sample-utterance.xlsx
```

Configuration is automatically read from `BOT-TO-TEST-CONFIGURATION-INFO.txt`.

### Advanced Options

```powershell
python main.py sample-utterance.xlsx `
  --output-dir test-output `
  --limit 5 `
  --config-file custom-config.txt
```

### Command Line Arguments

- **Required:**
  - `excel_file` - Path to Excel file with utterances (must have 'Utterance' column)

- **Optional:**
  - `--config-file` - Path to configuration file (default: `BOT-TO-TEST-CONFIGURATION-INFO.txt`)
  - `--output-dir` - Output directory (default: `test-output`)
  - `--limit` - Limit number of utterances to process (for testing)
  - `--skip-tts` - Skip TTS generation if audio files already exist
  - `--skip-testing` - Skip Dialogflow testing (only generate audio)

## Output Structure

```
test-output/
├── original/                    # Original MP3 audio files
│   └── utterance_1/
│       ├── 1_male_indian_english.mp3
│       └── ...
├── dialogflow-ready/           # Converted WAV files (16kHz, mono, 16-bit)
│   └── utterance_1/
│       ├── 1_male_indian_english.wav
│       └── ...
├── tts_results.json            # TTS generation results
├── test_results.json           # Dialogflow test results
├── test_report.xlsx            # Final Excel report
└── voice_mapping.json          # Voice mapping used
```

## Report Contents

The generated Excel report (`test_report.xlsx`) contains:

1. **Summary Sheet** - Overall statistics:
   - Total audio files tested
   - Successful/failed tests
   - Pass percentage

2. **Detailed Results Sheet** - Per-file results:
   - Original utterance
   - Audio variant (accent/gender)
   - Transcript from Dialogflow
   - Detected intent and confidence
   - Extracted parameters (headIntent, subIntent, etc.)
   - Response text

3. **Accent Summary** - Pass percentage per accent

4. **Gender Summary** - Pass percentage per gender

## Accents Supported

- Indian English
- French English
- Chinese English
- Spanish English
- African English
- Regular English

## Troubleshooting

### Audio Generation Issues
- **Edge TTS**: Ensure internet connection (Edge TTS requires online access)
- **Google TTS**: 
  - Verify `GOOGLE_APPLICATION_CREDENTIALS` environment variable is set (if not using service account key in config)
  - Ensure Cloud Text-to-Speech API is enabled in your Google Cloud project
  - Check that your service account has Text-to-Speech API permissions
- Check that Excel file has 'Utterance' column
- Verify output directory permissions

### Dialogflow Connection Issues
- Verify service account key file path
- Check that service account has Dialogflow CX permissions
- Ensure project ID, location, and agent ID are correct

### Audio Format Issues
- Audio files are automatically converted to 16kHz, mono, 16-bit PCM WAV
- If conversion fails, ensure `soundfile` and `scipy` are installed

## Module Details

### TTS Generator (`modules/tts_generator.py`)
- Supports both Google Cloud TTS (default, free tier available) and Edge TTS (free, no API key)
- Select TTS service via `TTS_SERVICE` configuration flag: "google" (default) or "edge"
- Generates 12 variations per utterance (2 genders × 6 accents)
- Automatically discovers and maps voices to accents
- Converts audio to Dialogflow-compatible format
- **Google TTS (default)**: Free tier: 4M chars/month (standard), 1M chars/month (WaveNet). Requires Google Cloud credentials.
- **Edge TTS**: Free, requires internet connection. Set `TTS_SERVICE = "edge"` to use.

### Dialogflow Client (`modules/dialogflow_client.py`)
- Handles authentication and connection
- Implements streaming audio API
- Extracts intents, parameters, and responses

### Audio Tester (`modules/audio_tester.py`)
- Finds and organizes audio files
- Tests each file sequentially
- Records all results for reporting

### Report Generator (`modules/report_generator.py`)
- Merges input utterances with test results
- Calculates pass percentages
- Generates formatted Excel reports
