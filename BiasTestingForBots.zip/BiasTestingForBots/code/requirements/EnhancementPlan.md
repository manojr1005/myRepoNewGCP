# Enhancement Plan: Multi-Accent Audio Testing for Dialogflow CX

## Overview
This document outlines the plan to enhance the Dialogflow CX NLU testing application to support audio-based testing with multiple accents and voice variations. The system will generate 12 audio variations per utterance (2 genders × 6 accents) and test them against the Dialogflow CX bot to measure accuracy across different speech patterns.

## Requirements Summary
1. **Input**: Excel file with utterances (`Test-utterences.xlsx`)
2. **Audio Generation**: Create 12 audio variations per utterance:
   - 2 genders: Male, Female
   - 6 accents: Indian English, French English, Chinese English, Spanish English, African English, Regular English
3. **Testing**: Feed audio files to Dialogflow CX bot
4. **Results**: Record bot responses and calculate percentage matches

## Technology Stack Selection

### 1. Text-to-Speech (TTS) Engine
**Recommended: Edge TTS (Microsoft Edge TTS)**
- **Why**: Free, open-source, supports multiple voices and accents
- **Pros**: 
  - No API keys required
  - High-quality voices
  - Supports multiple languages and accents
  - Python library available (`edge-tts`)
  - Can specify gender and accent
- **Cons**: Requires internet connection
- **Alternative**: Coqui TTS (fully offline, but more complex setup)

**Implementation Library**: `edge-tts` (Python)

### 2. Audio Processing
**Recommended: pydub + soundfile**
- **pydub**: Audio manipulation (format conversion, normalization)
- **soundfile**: High-quality audio file I/O
- **Why**: Lightweight, well-maintained, supports multiple formats

### 3. Dialogflow CX Audio Input
**Method**: Use Dialogflow CX Streaming API for audio input
- Dialogflow CX supports audio input via `streamingDetectIntent` API
- **Reference**: [Dialogflow CX Audio Input Documentation](https://docs.cloud.google.com/dialogflow/cx/docs/how/detect-intent-stream#detect-intent-audio-input-python)
- Uses streaming API for real-time audio processing
- Audio sent in chunks (4096 bytes recommended)
- Supports partial responses during processing
- Can be implemented in both Node.js and Python

### 4. Audio Format Requirements
- **Format**: RAW PCM or WAV (uncompressed)
- **Encoding**: `AUDIO_ENCODING_LINEAR_16` (16-bit PCM)
- **Sample Rate**: 16000 Hz (required by Dialogflow CX)
- **Channels**: Mono
- **Bit Depth**: 16-bit
- **Chunk Size**: 4096 bytes (recommended for streaming)

## Architecture Design

### Component Structure

```
TestingForBots/
├── backend/
│   ├── services/
│   │   ├── ttsService.js          # TTS audio generation
│   │   ├── audioProcessor.js      # Audio format conversion
│   │   └── dialogflowAudio.js     # Dialogflow audio testing
│   ├── routes/
│   │   └── audioTestRoutes.js     # Audio testing endpoints
│   └── utils/
│       └── accentMapper.js        # Accent to voice mapping
├── audio-service/                 # NEW: Python microservice for TTS
│   ├── tts_generator.py           # Main TTS generation script
│   ├── accent_config.py           # Accent and voice configurations
│   └── requirements.txt
└── generated-audio/               # Generated audio files storage
    ├── utterance_1/
    │   ├── male_indian.wav
    │   ├── male_french.wav
    │   └── ...
    └── utterance_2/
        └── ...
```

### Data Flow

```
1. User uploads Excel file → Backend extracts utterances
2. Backend sends utterances to Python TTS service
3. Python service generates 12 audio files per utterance
4. Audio files stored in organized directory structure
5. Backend reads audio files and sends to Dialogflow CX
6. Dialogflow CX processes audio and returns text + intents
7. Backend compares results and calculates match percentages
8. Results displayed in frontend with audio playback capability
```

## Implementation Plan

### Phase 1: TTS Audio Generation Service

#### 1.1 Python TTS Microservice
**File**: `audio-service/tts_generator.py`

**Features**:
- Read utterances from Excel or API
- Generate audio files with specified voice/accent combinations
- Organize output by utterance ID
- Return metadata about generated files

**Voice Mapping Strategy**:
```python
ACCENT_VOICE_MAP = {
    'indian_english': {
        'male': 'en-IN-Male',
        'female': 'en-IN-Female'
    },
    'french_english': {
        'male': 'en-FR-Male',  # French-accented English
        'female': 'en-FR-Female'
    },
    'chinese_english': {
        'male': 'en-CN-Male',  # Chinese-accented English
        'female': 'en-CN-Female'
    },
    'spanish_english': {
        'male': 'en-ES-Male',  # Spanish-accented English
        'female': 'en-ES-Female'
    },
    'african_english': {
        'male': 'en-ZA-Male',  # South African English (closest to African English)
        'female': 'en-ZA-Female'
    },
    'regular_english': {
        'male': 'en-US-Male',
        'female': 'en-US-Female'
    }
}
```

**Note**: Edge TTS voice names may vary. Actual implementation will need to:
1. List available voices: `edge-tts --list-voices`
2. Filter by language and gender
3. Map to desired accents

#### 1.2 Audio Processing & Format

**Edge TTS Output Format**:
- Edge TTS typically generates audio in **MP3 format** (default)
- Can also output as **WAV** or **OGG** depending on configuration
- Sample rate: Usually 24kHz or 48kHz (varies by voice)
- Channels: Usually stereo

**Conversion to Dialogflow Format**:
- **Input**: MP3/WAV from Edge TTS (any sample rate, stereo/mono)
- **Output**: 16kHz, mono, 16-bit PCM WAV (LINEAR_16) or FLAC
- **Tool**: `pydub` with `ffmpeg` backend for conversion
- **Process**:
  1. Load audio file (MP3/WAV from Edge TTS)
  2. Convert to mono (if stereo)
  3. Resample to 16000 Hz
  4. Export as 16-bit PCM WAV or FLAC
  5. Validate format before sending to Dialogflow

**File Storage**:
- **Initial Storage**: Save Edge TTS output as MP3 (smaller file size)
- **Dialogflow-Ready Storage**: Convert and save as WAV/FLAC in separate directory
- **Format**: `{utterance_id}_{gender}_{accent}.wav` (Dialogflow-ready format)

### Phase 2: Backend API Enhancements

#### 2.1 Audio Format Conversion
Before sending to Dialogflow, ensure audio is in correct format:
- Convert to 16kHz, mono, 16-bit PCM WAV
- Use `pydub` or `ffmpeg` for conversion
- Validate format before API call

#### 2.2 New API Endpoints

**POST `/api/generate-audio`**
- Input: List of utterances
- Output: Job ID and status
- Generates audio files asynchronously

**GET `/api/audio-status/:jobId`**
- Check generation progress
- Return list of generated files

**POST `/api/test-audio`**
- Input: Audio file path or audio bytes (multipart/form-data)
- Output: Dialogflow response with transcript, intents, and parameters
- Implementation: Uses `streamingDetectIntent` API
- Reference: [Node.js Audio Input Sample](https://docs.cloud.google.com/dialogflow/cx/docs/how/detect-intent-stream#detect-intent-audio-input-nodejs)

**POST `/api/test-audio-batch`**
- Input: List of audio file paths or array of audio files
- Output: Batch test results with per-file results
- Implementation: Processes files sequentially or in parallel (with rate limiting)

**POST `/api/audio-results-analysis`**
- Input: Test results
- Output: Match percentages, accuracy metrics

#### 2.2 Dialogflow Audio Integration

**Implementation** (Node.js - Streaming API):
```javascript
// Reference: https://docs.cloud.google.com/dialogflow/cx/docs/how/detect-intent-stream#detect-intent-audio-input-nodejs
const { SessionsClient } = require('@google-cloud/dialogflow-cx');
const fs = require('fs');
const { Transform, pipeline } = require('stream');

async function streamingDetectIntent(audioFilePath) {
  const sessionId = uuidv4();
  const sessionPath = client.projectLocationAgentSessionPath(
    projectId, location, agentId, sessionId
  );

  const request = {
    session: sessionPath,
    queryInput: {
      audio: {
        config: {
          audio_encoding: 'AUDIO_ENCODING_LINEAR_16',
          sampleRateHertz: 16000,
          singleUtterance: true,
        },
      },
      languageCode: 'en',
    },
    enablePartialResponse: true,
  };

  const stream = await client.streamingDetectIntent();
  
  stream.on('data', (data) => {
    if (data.detectIntentResponse) {
      const result = data.detectIntentResponse.queryResult;
      // Process response
    }
  });

  stream.write(request);

  // Stream audio file in chunks
  await pipeline(
    fs.createReadStream(audioFilePath),
    new Transform({
      objectMode: true,
      transform: (chunk, _, next) => {
        next(null, { queryInput: { audio: { audio: chunk } } });
      },
    }),
    stream
  );
}
```

**Implementation** (Python - Streaming API):
```python
# Reference: https://docs.cloud.google.com/dialogflow/cx/docs/how/detect-intent-stream#detect-intent-audio-input-python
from google.cloud.dialogflowcx_v3.services.sessions import SessionsClient
from google.cloud.dialogflowcx_v3.types import audio_config, session

def streaming_detect_intent(audio_file_name):
    session_id = str(uuid.uuid4())
    session_path = session_client.session_path(
        project=project_id, location=location, agent=agent_id, session=session_id
    )

    def request_generator():
        audio_encoding = audio_config.AudioEncoding['AUDIO_ENCODING_LINEAR_16']
        config = InputAudioConfig(
            audio_encoding=audio_encoding,
            sample_rate_hertz=16000,
            single_utterance=True,
        )
        audio_input = session.AudioInput(config=config)
        query_input = session.QueryInput(
            audio=audio_input, language_code='en'
        )
        yield session.StreamingDetectIntentRequest(
            session=session_path,
            query_input=query_input,
            enable_partial_response=True,
        )
        
        # Stream audio in chunks
        with open(audio_file_name, "rb") as audio_file:
            while True:
                chunk = audio_file.read(4096)  # 4KB chunks
                if not chunk:
                    break
                audio_input = session.AudioInput(audio=chunk, config=config)
                query_input = session.QueryInput(
                    audio=audio_input, language_code='en'
                )
                yield session.StreamingDetectIntentRequest(
                    session=session_path,
                    query_input=query_input,
                    enable_partial_response=True,
                )

    responses = session_client.streaming_detect_intent(
        requests=request_generator()
    )
    
    for response in responses:
        # Process partial and final responses
        if response.detect_intent_response:
            result = response.detect_intent_response.query_result
            # Extract transcript, intents, parameters
```

### Phase 3: Frontend Enhancements

#### 3.1 New Components

**AudioGenerationPanel.jsx**
- Show generation progress
- Display generated audio files
- Preview audio playback

**AudioTestRunner.jsx**
- Select audio variations to test
- Run audio tests
- Show real-time progress

**ResultsAnalysis.jsx**
- Display match percentages
- Show accuracy by accent/gender
- Visual charts (bar charts, pie charts)
- Export detailed reports

#### 3.2 Enhanced Results Table
- Add audio playback column
- Show accent/gender for each test
- Highlight matches/mismatches
- Filter by accent or gender

### Phase 4: Results Analysis & Reporting

#### 4.1 Match Calculation
- Compare expected vs actual intents
- Calculate accuracy per accent
- Calculate accuracy per gender
- Overall accuracy percentage

#### 4.2 Metrics to Track
- **Intent Match Rate**: % of correct intent classifications
- **Parameter Extraction Accuracy**: % of correctly extracted parameters
- **Response Quality**: Subjective or automated scoring
- **Accent Performance**: Which accents perform best/worst
- **Gender Bias**: Any differences between male/female voices

#### 4.3 Reporting
- Summary dashboard
- Detailed per-utterance breakdown
- Accent comparison charts
- Export to CSV/Excel with audio file references

## Technical Implementation Details

### Dependencies

**Python TTS Service** (`audio-service/requirements.txt`):
```
edge-tts==6.1.9
pydub==0.25.1
soundfile==0.12.1
pandas==2.1.3
openpyxl==3.1.2
flask==3.0.0
flask-cors==4.0.0
google-cloud-dialogflow-cx==1.38.0  # For audio testing if using Python
```

**Backend** (`backend/package.json` additions):
```json
{
  "@google-cloud/dialogflow-cx": "^4.0.0"  // Already included, supports streaming
}
```

**Note**: The Dialogflow CX client already supports streaming audio. No additional audio processing libraries needed for the Node.js backend if we use the built-in streaming API.

### File Naming Convention
```
{utterance_id}_{gender}_{accent}.wav

Examples:
- utterance_1_male_indian.wav
- utterance_1_female_french.wav
- utterance_2_male_regular.wav
```

### Storage Strategy
- **Local Development**: Store in `generated-audio/` directory
- **Production**: Consider cloud storage (S3, GCS) for scalability
- **Cleanup**: Implement cleanup job for old audio files

### Error Handling
- TTS generation failures (fallback to text testing)
- Audio format conversion errors
- Dialogflow API errors
- Network timeouts
- Invalid audio files

## Testing Strategy

### Unit Tests
- TTS generation for each accent/gender
- Audio format conversion
- Dialogflow audio API calls
- Result comparison logic

### Integration Tests
- End-to-end audio generation → testing → results
- Batch processing
- Error recovery

### Performance Tests
- Generation time for 100 utterances (1200 audio files)
- API response times
- Memory usage during batch processing

## Performance Considerations

### Optimization Strategies
1. **Parallel Processing**: Generate multiple audio files concurrently
2. **Caching**: Cache generated audio files (hash-based)
3. **Batch API Calls**: Group Dialogflow requests when possible
4. **Progressive Loading**: Stream results as they complete
5. **Background Jobs**: Use job queue for large batches

### Estimated Processing Times
- **Audio Generation**: ~2-3 seconds per file = ~30-40 seconds per utterance
- **Dialogflow Testing**: ~1-2 seconds per audio file
- **Total per utterance**: ~1-2 minutes (12 variations)
- **100 utterances**: ~2-3 hours (can be parallelized)

## Security Considerations

1. **File Upload Validation**: Validate audio file formats
2. **Storage Limits**: Implement quotas for generated files
3. **Access Control**: Secure audio file access
4. **API Rate Limiting**: Prevent abuse of TTS service
5. **Data Privacy**: Handle sensitive utterances appropriately

## Future Enhancements

1. **Custom Voice Training**: Train custom TTS models for specific accents
2. **Noise Injection**: Add background noise to test robustness
3. **Speed Variation**: Test at different speech rates
4. **Emotion Variation**: Test with different emotional tones
5. **Multi-language Support**: Extend to other languages
6. **Real-time Audio**: Support live audio input testing
7. **Voice Cloning**: Use voice cloning for consistent testing

## Implementation Phases

### Phase 1: Foundation (Week 1)
- [ ] Set up Python TTS service
- [ ] Implement basic audio generation
- [ ] Create accent/voice mapping
- [ ] Test with sample utterances

### Phase 2: Integration (Week 2)
- [ ] Integrate TTS service with backend
- [ ] Implement Dialogflow audio API calls
- [ ] Create audio testing endpoints
- [ ] Add audio file management

### Phase 3: Frontend (Week 3)
- [ ] Build audio generation UI
- [ ] Create audio test runner
- [ ] Implement results analysis dashboard
- [ ] Add audio playback features

### Phase 4: Analysis & Reporting (Week 4)
- [ ] Implement match calculation logic
- [ ] Create accuracy metrics
- [ ] Build reporting dashboard
- [ ] Add export functionality

### Phase 5: Optimization & Polish (Week 5)
- [ ] Performance optimization
- [ ] Error handling improvements
- [ ] Documentation
- [ ] Testing and bug fixes

## Alternative Approaches Considered

### 1. Coqui TTS (Fully Offline)
- **Pros**: No internet required, highly customizable
- **Cons**: Complex setup, larger model files, may require GPU
- **Decision**: Use as fallback if Edge TTS doesn't meet requirements

### 2. Google Cloud TTS
- **Pros**: High quality, many voices
- **Cons**: Requires API key, costs money, not fully open-source
- **Decision**: Not chosen due to cost and dependency

### 3. AWS Polly
- **Pros**: Good quality, many voices
- **Cons**: Requires AWS account, costs money
- **Decision**: Not chosen due to cost

### 4. Festival/eSpeak
- **Pros**: Fully offline, lightweight
- **Cons**: Lower quality, limited accent support
- **Decision**: Not chosen due to quality concerns

## Risk Mitigation

1. **Edge TTS Voice Availability**: 
   - Risk: Desired accents may not be available
   - Mitigation: Test voice availability first, have fallback options

2. **Audio Quality Issues**:
   - Risk: Generated audio may not be clear enough
   - Mitigation: Implement audio quality checks, normalization

3. **Dialogflow Audio Format**:
   - Risk: Format requirements are strict (16kHz, LINEAR_16, mono)
   - Mitigation: 
     - Use `pydub` for reliable format conversion
     - Validate audio format before sending to API
     - Test with sample files first
     - Reference: [Dialogflow CX Audio Input Docs](https://docs.cloud.google.com/dialogflow/cx/docs/how/detect-intent-stream#detect-intent-audio-input-python)

4. **Processing Time**:
   - Risk: Large batches may take too long
   - Mitigation: Implement background jobs, progress tracking

5. **Storage Requirements**:
   - Risk: Many audio files require significant storage
   - Mitigation: Implement cleanup policies, compression options

## Success Criteria

1. ✅ Successfully generate 12 audio variations per utterance
2. ✅ All audio files are Dialogflow-compatible format
3. ✅ Audio tests complete with >95% success rate (API calls)
4. ✅ Results show accurate match percentages
5. ✅ System handles 100+ utterances without errors
6. ✅ Processing time is acceptable (<3 hours for 100 utterances)
7. ✅ User-friendly interface for monitoring and results

## Next Steps

1. **Research Phase**: 
   - Test Edge TTS voice availability for required accents
   - Verify Dialogflow CX audio input format requirements ✅ (Documented in Google Cloud docs)
   - Create proof-of-concept with 1-2 utterances
   - Test streaming API with sample audio files

2. **Prototype**:
   - Build minimal TTS service
   - Generate test audio files in correct format (16kHz, LINEAR_16, mono)
   - Test Dialogflow streaming API integration
   - Validate approach before full implementation
   - Reference implementation: [Python Sample](https://docs.cloud.google.com/dialogflow/cx/docs/how/detect-intent-stream#detect-intent-audio-input-python) | [Node.js Sample](https://docs.cloud.google.com/dialogflow/cx/docs/how/detect-intent-stream#detect-intent-audio-input-nodejs)

3. **Full Implementation**:
   - Follow phased approach above
   - Regular testing and validation
   - User feedback integration

## Key Implementation Notes

### Streaming API Benefits
- **Real-time Processing**: Get partial results as audio is processed
- **Efficient**: Streams audio in chunks (4096 bytes)
- **Responsive**: Can show progress to users during processing

### Audio Processing Pipeline
1. TTS generates audio (Edge TTS) → MP3/WAV
2. Convert to Dialogflow format (pydub) → 16kHz, mono, LINEAR_16
3. Stream to Dialogflow in 4KB chunks
4. Receive partial and final responses
5. Extract transcript, intents, and parameters
6. Compare with expected results

---

**Document Version**: 1.0  
**Last Updated**: 2025-01-XX  
**Author**: AI Assistant  
**Status**: Planning Phase

