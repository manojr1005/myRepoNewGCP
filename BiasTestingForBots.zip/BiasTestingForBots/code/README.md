# Dialogflow CX Audio Testing Pipeline

A Python-based command-line tool for testing Dialogflow CX agents with audio input across multiple accents and voice variations. Generates TTS audio files, tests them with Dialogflow CX, and produces detailed reports.

## Features

- 🎤 **Multi-Accent Audio Generation**: Creates 12 audio variations per utterance (2 genders × 6 accents) using Google Cloud TTS (default) or Edge TTS
- 🧪 **Automated Testing**: Sends audio files to Dialogflow CX and records responses
- 📊 **Comprehensive Reports**: Generates Excel reports with pass percentages and detailed results
- ⚙️ **Flexible Configuration**: Configure via simple text file
- 🚀 **Command-Line Interface**: Easy to use from terminal/PowerShell

## Overview

This pipeline:
1. **Generates TTS audio files** - Creates 12 variations per utterance (2 genders × 6 accents) using Google Cloud TTS (default) or Edge TTS
2. **Tests with Dialogflow CX** - Sends audio files to Dialogflow and records responses
3. **Generates reports** - Creates Excel reports with pass percentages and detailed results

## Project Structure

```
TestingForBots/
├── audio-service/          # Python command-line tool
│   ├── main.py            # Main orchestrator script
│   ├── modules/
│   │   ├── tts_generator.py      # TTS audio generation (Google TTS/Edge TTS)
│   │   ├── dialogflow_client.py  # Dialogflow CX connection
│   │   ├── audio_tester.py       # Audio file testing
│   │   ├── report_generator.py   # Excel report generation
│   │   └── config_loader.py      # Configuration loader
│   ├── BOT-TO-TEST-CONFIGURATION-INFO.txt  # Configuration file
│   ├── requirements.txt    # Python dependencies
│   └── README.md          # Detailed documentation
└── README.md              # This file
```

## Prerequisites

- Python 3.8 or higher
- Google Cloud Project with Dialogflow CX agent
- Service Account JSON key file with Dialogflow CX API permissions
- (For Google TTS) Cloud Text-to-Speech API enabled
- (For Google TTS) Service account with Text-to-Speech API permissions

## Installation

1. Navigate to the audio-service directory:
```powershell
cd audio-service
```

2. Install Python dependencies:
```powershell
pip install -r requirements.txt
```

3. Configure settings:
   - Open `BOT-TO-TEST-CONFIGURATION-INFO.txt`
   - Update required parameters (see Configuration section below)

## Configuration

Edit `audio-service/BOT-TO-TEST-CONFIGURATION-INFO.txt` with your settings:

### Required Parameters:
- `PROJECT_ID` - Your Google Cloud Project ID
- `LOCATION` - Dialogflow CX location (e.g., `us-central1`, `global`)
- `AGENT_ID` - Your Dialogflow CX Agent ID (UUID)
- `CREDS_PATH` - Path to your service account JSON key file

### Optional Parameters:
- `FLOW_ID` - Flow ID to start from (leave empty for default)
- `PAGE_ID` - Page ID to start from (leave empty for default)
- `START_WITH_GREETING` - Set to `True`/`False`
- `TTS_SERVICE` - TTS service: `"google"` (default) or `"edge"`

### TTS Service Configuration:

**Google Cloud TTS (Default):**
- Set `TTS_SERVICE = "google"`
- Requires Cloud Text-to-Speech API enabled
- Requires service account with Text-to-Speech API permissions
- Free tier: 4M chars/month (standard), 1M chars/month (WaveNet)
- Pricing beyond free tier: $4 per 1M chars (standard), $16 per 1M chars (WaveNet)

**Edge TTS (Alternative):**
- Set `TTS_SERVICE = "edge"`
- Free, no API key required
- Requires internet connection
- Supports accented English voices

## Usage

### Basic Usage

```powershell
cd audio-service
python main.py sample-utterance.xlsx
```

### Advanced Options

```powershell
python main.py sample-utterance.xlsx `
  --output-dir test-output `
  --limit 5 `
  --skip-tts `
  --skip-testing
```

### Command Line Arguments

- **Required:**
  - `excel_file` - Path to Excel file with utterances (must have 'Utterance' column)

- **Optional:**
  - `--config-file` - Path to configuration file (default: `BOT-TO-TEST-CONFIGURATION-INFO.txt`)
  - `--output-dir` - Output directory (default: `test-output`)
  - `--limit` - Limit number of utterances to process (for testing)
  - `--skip-tts` - Skip TTS generation if audio files already exist
  - `--skip-testing` - Skip Dialogflow testing (only generate audio)

## Output Structure

```
test-output/
├── original/                    # Original MP3 audio files from TTS
│   └── utterance_1/
│       ├── 1_male_indian_english.mp3
│       └── ...
├── dialogflow-ready/           # Converted WAV files (16kHz, mono, 16-bit)
│   └── utterance_1/
│       ├── 1_male_indian_english.wav
│       └── ...
├── tts_results.json            # TTS generation results
├── test_results.json           # Dialogflow test results
├── test_report.xlsx            # Final Excel report
└── voice_mapping.json          # Voice mapping used
```

## Report Contents

The generated Excel report (`test_report.xlsx`) contains:

1. **Summary Sheet** - Overall statistics:
   - Total audio files tested
   - Successful/failed tests
   - Pass percentage

2. **Detailed Results Sheet** - Per-file results:
   - Original utterance
   - Audio variant (accent/gender)
   - Transcript from Dialogflow
   - Detected intent and confidence
   - Extracted parameters (headIntent, subIntent, etc.)
   - Response text

3. **Accent Summary** - Pass percentage per accent

4. **Gender Summary** - Pass percentage per gender

## Accents Supported

- Indian English
- French English
- Chinese English
- Spanish English
- African English
- Regular English

**Note:** Google Cloud TTS has limited support for "accented English" voices. French and Chinese English may use standard English voices. For better accent accuracy, consider using Edge TTS (`TTS_SERVICE = "edge"`).

## Troubleshooting

### Audio Generation Issues
- **Google TTS**: 
  - Verify Cloud Text-to-Speech API is enabled
  - Check service account has Text-to-Speech API permissions
  - Verify credentials file path is correct
- **Edge TTS**: Ensure internet connection
- Check that Excel file has 'Utterance' column
- Verify output directory permissions

### Dialogflow Connection Issues
- Verify service account key file path
- Check that service account has Dialogflow CX API permissions
- Ensure project ID, location, and agent ID are correct

### Audio Format Issues
- Audio files are automatically converted to 16kHz, mono, 16-bit PCM WAV
- If conversion fails, ensure `soundfile` and `scipy` are installed

## Module Details

### TTS Generator (`modules/tts_generator.py`)
- Supports Google Cloud TTS (default) and Edge TTS
- Select TTS service via `TTS_SERVICE` configuration flag
- Generates 12 variations per utterance (2 genders × 6 accents)
- Automatically discovers and maps voices to accents
- Converts audio to Dialogflow-compatible format

### Dialogflow Client (`modules/dialogflow_client.py`)
- Handles authentication and connection
- Implements streaming audio API
- Extracts intents, parameters, and responses

### Audio Tester (`modules/audio_tester.py`)
- Finds and organizes audio files
- Tests each file sequentially
- Records all results for reporting

### Report Generator (`modules/report_generator.py`)
- Merges input utterances with test results
- Calculates pass percentages
- Generates formatted Excel reports

## Examples

### Test with 1 utterance (quick test):
```powershell
python main.py sample-utterance.xlsx --limit 1
```

### Generate audio only (skip Dialogflow testing):
```powershell
python main.py sample-utterance.xlsx --skip-testing
```

### Test existing audio files (skip TTS generation):
```powershell
python main.py sample-utterance.xlsx --skip-tts
```

## License

ISC

## Author

Nikhil Kodilkar (2025)
